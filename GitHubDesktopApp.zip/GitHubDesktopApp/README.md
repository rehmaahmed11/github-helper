# GitHub Desktop for Android

Native Android GitHub client built with Jetpack Compose.

## Auth
Uses **OAuth 2.0 Authorization Code + PKCE (S256)**.
- No client secret is stored in the app.
- Each user logs into their own GitHub account.

## Setup
1. Create an OAuth App: https://github.com/settings/developers
   - Homepage URL: any (e.g. `https://github.com`)
   - Authorization callback URL: `githubdesktop://callback`
2. Copy the **Client ID** into `app/build.gradle.kts`
   (`buildConfigField GITHUB_CLIENT_ID`).
3. Do **not** add a client secret. PKCE does not need one.

## Features
- Sign in with GitHub via system browser (Custom Tabs)
- List, create, delete repos, toggle public/private
- Browse files and folders
- Upload files / folders
- Edit / delete / download files
- "Clone" (download repo contents) into a user-picked folder
- After push: prompt to merge working branch into main + delete it

## Build
Push to GitHub -> Actions -> "Build APK" -> artifacts -> app-debug.apk
