package com.example.githubdesktop

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.example.githubdesktop.auth.OAuthManager
import com.example.githubdesktop.auth.TokenStore
import com.example.githubdesktop.data.api.GitHubClient
import com.example.githubdesktop.ui.AppViewModel
import com.example.githubdesktop.ui.screens.LoginScreen
import com.example.githubdesktop.ui.screens.RootNav
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()
    private lateinit var tokenStore: TokenStore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tokenStore = (application as GitHubApp).tokenStore

        handleRedirect(intent)

        setContent {
            var loggedIn by remember { mutableStateOf(tokenStore.getToken() != null) }

            if (loggedIn) {
                GitHubClient.setToken(tokenStore.getToken())
                LaunchedEffect(Unit) { vm.loadUserAndRepos() }
                RootNav(
                    vm = vm,
                    login = tokenStore.getLogin() ?: "user",
                    onLogout = {
                        tokenStore.clear()
                        GitHubClient.setToken(null)
                        loggedIn = false
                    }
                )
            } else {
                LoginScreen(
                    onLogin = { OAuthManager.launchLogin(this@MainActivity) }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleRedirect(intent)
    }

    /**
     * PKCE redirect lands here: githubdesktop://callback?code=...
     * We exchange code + in-memory code_verifier for an access token.
     */
    private fun handleRedirect(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme != "githubdesktop" || data.host != "callback") return

        val code = data.getQueryParameter("code") ?: run {
            OAuthManager.cancel()
            return
        }

        lifecycleScope.launch {
            val token = OAuthManager.exchangeCode(code)
            if (token != null) {
                GitHubClient.setToken(token)
                val me = GitHubClient.api.me().body()
                tokenStore.saveToken(token, me?.login ?: "user")
                recreate() // refresh UI to enter logged-in state
            } else {
                OAuthManager.cancel()
            }
        }
    }
}
