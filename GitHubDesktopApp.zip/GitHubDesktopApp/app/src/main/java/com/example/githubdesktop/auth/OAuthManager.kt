package com.example.githubdesktop.auth

import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import com.example.githubdesktop.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * GitHub OAuth 2.0 Authorization Code + PKCE (S256).
 *
 * - No client secret in the app.
 * - Each user authorizes with their own GitHub account.
 * - code_verifier is held in memory only; never written to disk.
 */
object OAuthManager {

    const val REDIRECT_URI = "githubdesktop://callback"

    private const val AUTHORIZE_URL = "https://github.com/login/oauth/authorize"
    private const val TOKEN_URL = "https://github.com/login/oauth/access_token"
    private const val SCOPES = "repo user delete_repo"

    /** Holds the verifier between /authorize and /access_token. Memory only. */
    @Volatile
    var pendingVerifier: String? = null
        private set

    fun launchLogin(context: Context) {
        val verifier = Pkce.generateVerifier()
        val challenge = Pkce.challengeS256(verifier)
        pendingVerifier = verifier

        val url = Uri.parse(AUTHORIZE_URL).buildUpon()
            .appendQueryParameter("client_id", BuildConfig.GITHUB_CLIENT_ID)
            .appendQueryParameter("redirect_uri", REDIRECT_URI)
            .appendQueryParameter("scope", SCOPES)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("code_challenge", challenge)
            .appendQueryParameter("code_challenge_method", "S256")
            .build()
            .toString()

        CustomTabsIntent.Builder().build().launchUrl(context, Uri.parse(url))
    }

    /** Exchanges ?code=... + code_verifier for an access token. */
    suspend fun exchangeCode(code: String): String? = withContext(Dispatchers.IO) {
        val verifier = pendingVerifier ?: return@withContext null

        val body = FormBody.Builder()
            .add("client_id", BuildConfig.GITHUB_CLIENT_ID)
            .add("code", code)
            .add("redirect_uri", REDIRECT_URI)
            .add("code_verifier", verifier)
            .build()

        val req = Request.Builder()
            .url(TOKEN_URL)
            .header("Accept", "application/json")
            .post(body)
            .build()

        runCatching {
            val resp = OkHttpClient().newCall(req).execute()
            val raw = resp.body?.string() ?: return@runCatching null
            val json = JSONObject(raw)
            json.optString("access_token").takeIf { it.isNotBlank() }
        }.getOrNull().also {
            // One-shot: verifier no longer needed.
            pendingVerifier = null
        }
    }

    fun cancel() {
        pendingVerifier = null
    }
}
