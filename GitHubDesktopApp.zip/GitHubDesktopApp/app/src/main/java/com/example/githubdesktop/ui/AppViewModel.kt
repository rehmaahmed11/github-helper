package com.example.githubdesktop.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.githubdesktop.data.RepoRepository
import com.example.githubdesktop.data.api.GitHubClient
import com.example.githubdesktop.data.model.Branch
import com.example.githubdesktop.data.model.ContentItem
import com.example.githubdesktop.data.model.Repo
import com.example.githubdesktop.data.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class AppViewModel(
    private val repo: RepoRepository = RepoRepository()
) : ViewModel() {

    val repos = MutableStateFlow<List<Repo>>(emptyList())
    val user = MutableStateFlow<User?>(null)
    val loading = MutableStateFlow(false)
    val error = MutableStateFlow<String?>(null)

    val contents = MutableStateFlow<List<ContentItem>>(emptyList())
    val branches = MutableStateFlow<List<Branch>>(emptyList())

    fun loadUserAndRepos() {
        viewModelScope.launch {
            loading.value = true
            error.value = null
            runCatching {
                GitHubClient.api.me().body()?.let { user.value = it }
                repo.listRepos().body()?.let { repos.value = it }
            }.onFailure { error.value = it.message }
            loading.value = false
        }
    }

    fun createRepo(name: String, desc: String?, private: Boolean, onDone: () -> Unit) {
        viewModelScope.launch {
            runCatching {
                val r = repo.createRepo(name, desc, private)
                if (r.isSuccessful) { loadUserAndRepos(); onDone() }
                else error.value = "Create failed: ${r.code()}"
            }.onFailure { error.value = it.message }
        }
    }

    fun deleteRepo(owner: String, name: String, onDone: () -> Unit) {
        viewModelScope.launch {
            runCatching {
                val r = repo.deleteRepo(owner, name)
                if (r.isSuccessful) {
                    repos.value = repos.value.filterNot { it.name == name }
                    onDone()
                } else error.value = "Delete failed: ${r.code()}"
            }.onFailure { error.value = it.message }
        }
    }

    fun setVisibility(owner: String, name: String, private: Boolean) {
        viewModelScope.launch {
            runCatching {
                val r = repo.setVisibility(owner, name, private)
                if (r.isSuccessful) loadUserAndRepos()
                else error.value = "Update failed: ${r.code()}"
            }.onFailure { error.value = it.message }
        }
    }

    fun loadContents(owner: String, name: String, path: String) {
        viewModelScope.launch {
            loading.value = true
            runCatching {
                contents.value = repo.listContents(owner, name, path, null).body().orEmpty()
            }.onFailure { error.value = it.message }
            loading.value = false
        }
    }

    fun loadBranches(owner: String, name: String) {
        viewModelScope.launch {
            runCatching {
                branches.value = repo.listBranches(owner, name).body().orEmpty()
            }.onFailure { error.value = it.message }
        }
    }
}
