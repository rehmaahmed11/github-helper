package com.example.githubdesktop.ui.components

import android.util.Base64
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.githubdesktop.data.RepoRepository
import com.example.githubdesktop.data.model.ContentItem
import com.example.githubdesktop.ui.util.SafHelper

@Composable
fun FileEditorDialog(
    owner: String,
    repo: String,
    file: ContentItem,
    branch: String,
    onDismiss: () -> Unit,
    onSaved: (workingBranch: String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val r = remember { RepoRepository() }
    var content by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var saveError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(file.path) {
        if (file.sha.isNotEmpty()) {
            withContext(Dispatchers.IO) {
                val resp = r.getFile(owner, repo, file.path, branch)
                resp.body()?.let {
                    content = try {
                        String(Base64.decode(it.content.replace("\n", ""), Base64.DEFAULT))
                    } catch (e: Exception) { "" }
                }
                loading = false
            }
        } else loading = false
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit ${file.path}") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp, max = 400.dp),
                    label = { Text("Content") }
                )
                saveError?.let {
                    Spacer(Modifier.height(8.dp))
                    Text(it, color = MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                scope.launch {
                    saveError = null
                    val working = SafHelper.newWorkingBranch()
                    val headSha = r.headSha(owner, repo, branch)
                    if (headSha != null) r.createBranch(owner, repo, working, headSha)

                    val ok = SafHelper.putFile(
                        r, owner, repo, file.path,
                        content.toByteArray(),
                        file.sha.ifEmpty { null },
                        working,
                        "Edit ${file.path} via mobile"
                    )
                    if (ok) onSaved(working) else saveError = "Save failed"
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
