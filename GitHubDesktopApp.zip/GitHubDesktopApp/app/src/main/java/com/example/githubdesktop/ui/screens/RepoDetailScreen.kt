package com.example.githubdesktop.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import com.example.githubdesktop.GitHubApp
import com.example.githubdesktop.data.model.ContentItem
import com.example.githubdesktop.ui.AppViewModel
import com.example.githubdesktop.ui.components.BranchMergeDialog
import com.example.githubdesktop.ui.components.FileEditorDialog
import com.example.githubdesktop.ui.util.Cloner
import com.example.githubdesktop.ui.util.FolderUploader
import com.example.githubdesktop.ui.util.SafHelper

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun RepoDetailScreen(
    vm: AppViewModel,
    owner: String,
    name: String,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val contents by vm.contents.collectAsState()
    val loading by vm.loading.collectAsState()

    var currentPath by remember { mutableStateOf("") }
    var currentBranch by remember { mutableStateOf("main") }
    var showUploadMenu by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ContentItem?>(null) }
    var deleting by remember { mutableStateOf<ContentItem?>(null) }
    var showMergeDialog by remember { mutableStateOf<String?>(null) }
    var isPrivate by remember { mutableStateOf(false) }

    LaunchedEffect(currentPath) { vm.loadContents(owner, name, currentPath) }
    LaunchedEffect(Unit) {
        vm.loadBranches(owner, name)
        vm.repos.value.find { it.name == name }?.let { isPrivate = it.private }
    }

    val uploadFiles = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            scope.launch {
                val working = SafHelper.newWorkingBranch()
                SafHelper.pushFiles(ctx, vm, owner, name, currentPath, uris, working)
                showMergeDialog = working
            }
        }
    }

    val uploadFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let {
            scope.launch {
                val working = SafHelper.newWorkingBranch()
                FolderUploader.uploadTree(ctx, vm, owner, name, currentPath, uri, working)
                showMergeDialog = working
            }
        }
    }

    val cloneFolder = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        uri?.let {
            scope.launch {
                val token = (ctx.applicationContext as GitHubApp).tokenStore.getToken()
                if (token != null) {
                    Cloner.downloadAndExtract(ctx, token, owner, name, uri)
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(name, fontWeight = FontWeight.SemiBold)
                        Text(
                            "branch: $currentBranch · /$currentPath",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (currentPath.isEmpty()) onBack()
                        else currentPath = currentPath.substringBeforeLast('/', "")
                    }) { Icon(Icons.Filled.ArrowBack, null) }
                },
                actions = {
                    IconButton(onClick = { cloneFolder.launch(null) }) {
                        Icon(Icons.Filled.Download, contentDescription = "Clone")
                    }
                    IconButton(onClick = {
                        isPrivate = !isPrivate
                        vm.setVisibility(owner, name, isPrivate)
                    }) {
                        Icon(
                            if (isPrivate) Icons.Filled.Lock else Icons.Filled.LockOpen,
                            contentDescription = "Toggle visibility"
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showUploadMenu = true }) {
                Icon(Icons.Filled.Add, null)
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())

            LazyColumn(Modifier.fillMaxSize()) {
                items(contents, key = { it.sha + it.path }) { item ->
                    ListItem(
                        headlineContent = { Text(item.name) },
                        leadingContent = {
                            Icon(
                                if (item.type == "dir") Icons.Filled.Folder
                                else Icons.Filled.Description,
                                null
                            )
                        },
                        supportingContent = {
                            if (item.type == "file") Text("${item.size} bytes")
                            else Text("folder")
                        },
                        modifier = Modifier.combinedClickable(
                            onClick = {
                                if (item.type == "dir") currentPath = item.path
                                else editing = item
                            },
                            onLongClick = {
                                if (item.type == "file") deleting = item
                            }
                        )
                    )
                    HorizontalDivider()
                }
            }
        }
    }

    if (showUploadMenu) {
        ModalBottomSheet(onDismissRequest = { showUploadMenu = false }) {
            ListItem(
                headlineContent = { Text("Upload files") },
                leadingContent = { Icon(Icons.Filled.UploadFile, null) },
                modifier = Modifier.clickable {
                    showUploadMenu = false
                    uploadFiles.launch(arrayOf("*/*"))
                }
            )
            ListItem(
                headlineContent = { Text("Upload folder") },
                leadingContent = { Icon(Icons.Filled.CreateNewFolder, null) },
                modifier = Modifier.clickable {
                    showUploadMenu = false
                    uploadFolder.launch(null)
                }
            )
            ListItem(
                headlineContent = { Text("Create new file") },
                leadingContent = { Icon(Icons.Filled.NoteAdd, null) },
                modifier = Modifier.clickable {
                    showUploadMenu = false
                    val path = if (currentPath.isEmpty()) "new-file.txt"
                               else "$currentPath/new-file.txt"
                    editing = ContentItem(
                        name = "new-file.txt", path = path, sha = "",
                        size = 0, type = "file", downloadUrl = null
                    )
                }
            )
        }
    }

    editing?.let { file ->
        FileEditorDialog(
            owner = owner, repo = name, file = file,
            branch = currentBranch,
            onDismiss = { editing = null },
            onSaved = { working ->
                editing = null
                showMergeDialog = working
            }
        )
    }

    deleting?.let { file ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete file") },
            text = { Text("Delete ${file.path}?") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        val working = SafHelper.newWorkingBranch()
                        val ok = SafHelper.deleteViaBranch(
                            vm, owner, name, file.path, file.sha, working, currentBranch
                        )
                        deleting = null
                        if (ok) showMergeDialog = working
                    }
                }) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text("Cancel") }
            }
        )
    }

    showMergeDialog?.let { working ->
        BranchMergeDialog(
            workingBranch = working,
            mainBranch = "main",
            onDismiss = { showMergeDialog = null },
            onConfirm = { merge, deleteAfter ->
                scope.launch {
                    if (merge) SafHelper.mergeToMain(vm, owner, name, "main", working)
                    if (deleteAfter) SafHelper.deleteBranch(vm, owner, name, working)
                    showMergeDialog = null
                    vm.loadContents(owner, name, currentPath)
                }
            }
        )
    }
}
