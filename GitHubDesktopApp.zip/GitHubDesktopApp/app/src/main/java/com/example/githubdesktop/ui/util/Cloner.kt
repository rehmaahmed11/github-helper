package com.example.githubdesktop.ui.util

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.zip.ZipInputStream

/**
 * V1 "clone": download repo zipball via API and extract into a
 * user-picked SAF folder. No storage permissions needed.
 * (True JGit clone with history comes in V2.)
 */
object Cloner {

    suspend fun downloadAndExtract(
        ctx: Context, token: String, owner: String, repo: String, destTreeUri: Uri
    ) = withContext(Dispatchers.IO) {
        val url = "https://api.github.com/repos/$owner/$repo/zipball"
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .build()

        val body = OkHttpClient().newCall(req).execute().body ?: return@withContext
        val root = DocumentFile.fromTreeUri(ctx, destTreeUri) ?: return@withContext

        ZipInputStream(body.byteStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val parts = entry.name.split("/").drop(1) // drop "repo-sha/" prefix
                if (parts.isNotEmpty() && !entry.isDirectory) {
                    var dir = root
                    for (i in 0 until parts.size - 1) {
                        val seg = parts[i]
                        dir = dir.findFile(seg) ?: dir.createDirectory(seg)!!
                    }
                    val f = dir.createFile("application/octet-stream", parts.last())
                    if (f != null) {
                        ctx.contentResolver.openOutputStream(f.uri)?.use {
                            zis.copyTo(it)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
}
