package com.example.githubdesktop.ui.util

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.example.githubdesktop.data.RepoRepository
import com.example.githubdesktop.ui.AppViewModel

object FolderUploader {

    suspend fun uploadTree(
        ctx: Context, vm: AppViewModel, owner: String, repo: String,
        basePath: String, treeUri: Uri, working: String
    ) {
        val r = RepoRepository()
        val headSha = r.headSha(owner, repo, "main") ?: return
        r.createBranch(owner, repo, working, headSha)

        val root = DocumentFile.fromTreeUri(ctx, treeUri) ?: return
        val rootName = root.name ?: "folder"
        val prefix = if (basePath.isBlank()) rootName else "$basePath/$rootName"

        walk(ctx, r, owner, repo, prefix, root, working)
    }

    private suspend fun walk(
        ctx: Context, r: RepoRepository, owner: String, repo: String,
        path: String, dir: DocumentFile, branch: String
    ) {
        dir.listFiles().forEach { child ->
            if (child.isDirectory) {
                walk(ctx, r, owner, repo, "$path/${child.name}", child, branch)
            } else {
                val bytes = runCatching {
                    ctx.contentResolver.openInputStream(child.uri)!!.use { it.readBytes() }
                }.getOrNull() ?: return@forEach
                SafHelper.putFile(
                    r, owner, repo, "$path/${child.name}",
                    bytes, null, branch, "Upload ${child.name}"
                )
            }
        }
    }
}
