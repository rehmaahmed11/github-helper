package com.example.githubdesktop.ui.util

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.githubdesktop.data.RepoRepository
import com.example.githubdesktop.ui.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SafHelper {

    fun newWorkingBranch(): String {
        val f = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US)
        return "mobile-edit-${f.format(Date())}"
    }

    fun readBytes(ctx: Context, uri: Uri): ByteArray =
        ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }

    fun fileName(ctx: Context, uri: Uri): String {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) return c.getString(idx)
        }
        return uri.lastPathSegment ?: "file"
    }

    suspend fun putFile(
        r: RepoRepository,
        owner: String, repo: String, path: String,
        bytes: ByteArray, sha: String?, branch: String, message: String
    ): Boolean = try {
        r.putFile(owner, repo, path, bytes, sha, branch, message).isSuccessful
    } catch (e: Exception) { false }

    suspend fun deleteViaBranch(
        vm: AppViewModel, owner: String, repo: String,
        path: String, sha: String, working: String, base: String
    ): Boolean {
        val r = RepoRepository()
        val headSha = r.headSha(owner, repo, base) ?: return false
        r.createBranch(owner, repo, working, headSha)
        return r.deleteFile(owner, repo, path, sha, working, "Delete $path via mobile").isSuccessful
    }

    suspend fun mergeToMain(
        vm: AppViewModel, owner: String, repo: String, base: String, head: String
    ): Boolean = try {
        RepoRepository().merge(owner, repo, base, head).isSuccessful
    } catch (e: Exception) { false }

    suspend fun deleteBranch(
        vm: AppViewModel, owner: String, repo: String, branch: String
    ): Boolean = try {
        RepoRepository().deleteBranch(owner, repo, branch).isSuccessful
    } catch (e: Exception) { false }

    suspend fun pushFiles(
        ctx: Context, vm: AppViewModel, owner: String, repo: String,
        basePath: String, uris: List<Uri>, working: String
    ) {
        val r = RepoRepository()
        val headSha = r.headSha(owner, repo, "main") ?: return
        r.createBranch(owner, repo, working, headSha)
        uris.forEach { uri ->
            val name = fileName(ctx, uri)
            val path = if (basePath.isBlank()) name else "$basePath/$name"
            val bytes = runCatching { readBytes(ctx, uri) }.getOrNull() ?: return@forEach
            putFile(r, owner, repo, path, bytes, null, working, "Add $name via mobile")
        }
    }
}
